package com.guru.composecookbook.meditation.ui.theme

import androidx.compose.ui.unit.dp

val dp5 = 5.dp
val dp10 = 10.dp
val dp15 = 15.dp
val dp20 = 20.dp
val dp25 = 25.dp