package com.guru.composecookbook.datingapp.util

fun Boolean?.orFalse(): Boolean = this ?: false
