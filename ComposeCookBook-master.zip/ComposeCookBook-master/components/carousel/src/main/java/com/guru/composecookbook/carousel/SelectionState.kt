package com.guru.composecookbook.carousel

enum class SelectionState {
    Selected,
    Undecided
}
