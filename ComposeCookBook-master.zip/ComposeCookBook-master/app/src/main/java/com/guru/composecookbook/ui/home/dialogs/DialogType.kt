package com.guru.composecookbook.ui.home.dialogs

enum class DialogType {
    SIMPLE, TITLE, VERTICALBUTTON, IMAGE, LONGDIALOG, ROUNDED, DATEPICKER, TIMEPICKER
}