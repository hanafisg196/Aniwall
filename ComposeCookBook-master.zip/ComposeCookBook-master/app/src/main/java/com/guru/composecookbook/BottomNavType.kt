package com.guru.composecookbook

enum class BottomNavType {
    HOME,
    WIDGETS,
    ANIMATION,
    DEMOUI,
    TEMPLATE
}