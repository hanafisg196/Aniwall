package com.guru.composecookbook.ui.utils

fun Boolean?.orFalse(): Boolean = this ?: false
