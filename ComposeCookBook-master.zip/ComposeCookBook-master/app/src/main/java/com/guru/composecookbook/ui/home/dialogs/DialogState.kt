package com.guru.composecookbook.ui.home.dialogs

data class DialogState(var showDialog: Boolean, var dialogType: DialogType)