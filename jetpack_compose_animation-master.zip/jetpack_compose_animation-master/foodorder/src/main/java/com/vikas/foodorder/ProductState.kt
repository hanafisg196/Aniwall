package com.vikas.foodorder

enum class ButtonState {
    Details, AddToCart
}